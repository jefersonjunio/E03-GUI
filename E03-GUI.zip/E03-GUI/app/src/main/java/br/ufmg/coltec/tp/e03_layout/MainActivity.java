package br.ufmg.coltec.tp.e03_layout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    Button bt_entrar_splash;
    Button bt_entrar_noticia;
    Button bt_entrar_previsao;
    Button bt_entrar_formulario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_entrar_splash = findViewById(R.id.bt_entrar_splash);
        bt_entrar_noticia = findViewById(R.id.bt_entrar_noticia);
        bt_entrar_previsao = findViewById(R.id.bt_entrar_previsao);
        bt_entrar_formulario = findViewById(R.id.bt_entrar_formulario);

        bt_entrar_splash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SplashScreen.class);
                startActivity(intent);

            }
        });

        bt_entrar_noticia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Noticia.class);
                startActivity(intent);
            }
        });

        bt_entrar_previsao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, PrevisaoTempo.class);
                startActivity(intent);
            }
        });

        bt_entrar_formulario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Formulario.class);
                startActivity(intent);
            }
        });
    }
}
