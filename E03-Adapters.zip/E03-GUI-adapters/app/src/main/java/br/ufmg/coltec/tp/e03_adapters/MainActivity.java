package br.ufmg.coltec.tp.e03_adapters;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import br.ufmg.coltec.PlaceAdapters;
import br.ufmg.coltec.e03_adapters.R;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView placesList = findViewById(R.id.places_list);
        placesList.setAdapter(new PlaceAdapters(this));
    }
}
