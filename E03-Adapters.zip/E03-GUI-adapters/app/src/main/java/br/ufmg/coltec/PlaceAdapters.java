package br.ufmg.coltec;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import br.ufmg.coltec.e03_adapters.Place;
import br.ufmg.coltec.e03_adapters.R;

public class PlaceAdapters extends BaseAdapter {
    private List<Place> places;
    private Context context;

    public PlaceAdapters(Context context) {
        this.context = context;
        this.places = new ArrayList<>();

        carregarLista();
    }

    public void carregarLista() {
        this.places.add(new Place("Monte do Girassol", R.drawable.girassol, 5.5, 5.0, "Girassois lindos!" ));
        this.places.add(new Place("Paris", R.drawable.paris, 6.5, 2.0,"Lugar maravilhoso, tbt!" ));
        this.places.add(new Place("Mineirao", R.drawable.mineirao, 8.5, 3.0, "Estádio grande e bonito! Uau #tbt" ));
    }

    @Override
    public int getCount() {
        return this.places.size();
    }

    @Override
    public Object getItem(int i) {
        return this.places.get(i);
    }

    @Override
    public long getItemId(int i) {
        //Place place = this.places.get(i);
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        Place place = this.places.get(i);
        View newView = LayoutInflater.from(this.context).inflate(R.layout.list_item_place, viewGroup, false);

        TextView tv_name = newView.findViewById(R.id.txt_place_name);
        TextView tv_description = newView.findViewById(R.id.txt_place_description);
        ImageView img_photo = newView.findViewById(R.id.img_place_photo);
        TextView tv_distance = newView.findViewById(R.id.txt_place_distance);
        RatingBar rt_stars = newView.findViewById(R.id.rt_stars);

        tv_name.setText(place.getName());
        tv_distance.setText(place.getDistance().toString());
        tv_description.setText(place.getDescription());
        img_photo.setImageResource(place.getPhotoId());
        rt_stars.setNumStars(place.getRate().byteValue());

        return newView;
    }
}
