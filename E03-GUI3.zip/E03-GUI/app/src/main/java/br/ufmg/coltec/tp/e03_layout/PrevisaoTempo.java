package br.ufmg.coltec.tp.e03_layout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PrevisaoTempo extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_previsao_tempo);
    }
}