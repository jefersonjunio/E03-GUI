package br.ufmg.coltec.tp.e03_layout;

import android.content.DialogInterface;
import android.content.Intent;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Formulario extends MainActivity{

    Button bt_voltar;
    Button bt_enviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        bt_voltar = findViewById(R.id.bt_form_voltar);
        bt_enviar = findViewById(R.id.bt_enviar);

        bt_enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alerta(view);
            }
        });
        
        bt_voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Formulario.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void Alerta(View view) {
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(this);

        alertBuilder.setIcon(R.drawable.ic_launcher_foreground);
        alertBuilder.setTitle(R.string.txt_aviso);
        alertBuilder.setMessage(R.string.txt_confirmar);

        alertBuilder.setPositiveButton(R.string.txt_sim, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getBaseContext(), R.string.txt_avaliacao_enviada, Toast.LENGTH_SHORT).show();
            }
        });

        alertBuilder.setNegativeButton(R.string.txt_nao, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getBaseContext(), R.string.txt_avaliacao_nao_enviada, Toast.LENGTH_SHORT).show();
            }
        });

        AlertDialog dialog = alertBuilder.create();
        dialog.show();
    }
}